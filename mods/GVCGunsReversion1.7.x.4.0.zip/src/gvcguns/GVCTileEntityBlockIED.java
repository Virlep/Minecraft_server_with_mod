package gvcguns;

import net.minecraft.tileentity.TileEntity;

public class GVCTileEntityBlockIED extends TileEntity
{
	//public GVCTileEntityItemG36()
	{
	}
}
