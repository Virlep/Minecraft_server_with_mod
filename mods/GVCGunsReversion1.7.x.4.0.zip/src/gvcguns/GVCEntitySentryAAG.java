package gvcguns;

import gvcguns.GVCEntityGrenade;
import gvcguns.GVCGunsPlus;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityFlying;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.IRangedAttackMob;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIArrowAttack;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIFleeSun;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAIMoveTowardsTarget;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAIRestrictSun;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAITempt;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.monster.EntityCreeper;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.entity.monster.EntityGolem;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityLargeFireball;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.stats.AchievementList;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.EnumSkyBlock;
import net.minecraft.world.World;
import net.minecraft.world.WorldProviderHell;

public class GVCEntitySentryAAG extends EntityGolem implements IRangedAttackMob
{
	//private static final EntityCreature EntityCreature = null;
	private EntityAIArrowAttack aiArrowAttack = new EntityAIArrowAttack(this, 1.0D, 4, 4, 100.0F);
	private Entity targetedEntity;
	private int aggroCooldown;
    public int prevAttackCounter;
    public int attackCounter;
    public List playerEntities = new ArrayList();
    
    int i = 0;
    
	//private EntityAIAttackOnCollide aiAttackOnCollide = new EntityAIAttackOnCollide(this, EntityPlayer.class, 1.2D, false);
	
    public GVCEntitySentryAAG(World par1World)
    {
        super(par1World);
        this.setSize(1.0F, 20.5F);
        this.getNavigator().setAvoidsWater(true);
        this.tasks.addTask(1, new EntityAIArrowAttack(this, 1.0D, 10, 10, 100.0F));
        this.tasks.addTask(2, new EntityAIMoveTowardsTarget(this, 1.0D, 100.0F));
        this.tasks.addTask(2, new EntityAIWander(this, 1.0D));
        this.tasks.addTask(3, new EntityAIWatchClosest(this, EntityPlayer.class, 20.0F));
        this.tasks.addTask(4, new EntityAILookIdle(this));
        //this.tasks.addTask(4, new EntityAITempt(this, 1.2D, Items.carrot.itemID, false));
        this.targetTasks.addTask(1, new EntityAINearestAttackableTarget(this, EntityLiving.class, 0, true, false, IMob.mobSelector));
        this.targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityGhast.class, 0, true));
        this.targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityCreeper.class, 0, true));
        this.targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityFlying.class, 0, true));
        
    }
    
    
    
    
    @SideOnly(Side.CLIENT)
    public int getBrightnessForRender(float par1)
    {
        return 15728880;
    }

    /**
     * Gets how bright this entity is.
     */
    public float getBrightness(float par1)
    {
        return 1.0F;
    }
    
    
    
    public boolean canAttackClass(Class par1Class)
    {
        return EntityCreature.class != par1Class;
    }
    
    
    protected boolean canDespawn()
    {
        return false;
    }
    
    
    public void onLivingUpdate()
    {
        this.updateArmSwingProgress();
        float f = this.getBrightness(1.0F);
        
        
        double d4 = 100.0D;

        if (this.targetedEntity != null && this.targetedEntity.getDistanceSqToEntity(this) < d4 * d4)
        {
        	//this.getClosestVulnerableEntityToEntity(this, 100.0D);
        }

        if (f > 0.5F)
        {
            this.entityAge += 2;
        }

        super.onLivingUpdate();
    }

    
    
    /**
     * Returns true if the newer Entity AI code should be run
     */
    public boolean isAIEnabled()
    {
        return true;
    }

    protected void applyEntityAttributes()
    {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0D);
        this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(50.0D);
        this.getEntityAttribute(SharedMonsterAttributes.followRange).setBaseValue(100.0D);
        this.getEntityAttribute(SharedMonsterAttributes.knockbackResistance).setBaseValue(30.0D);
    }


    protected void addRandomArmor()
    {
        super.addRandomArmor();
        //this.setCurrentItemOrArmor(0, new ItemStack(GVCGunsPlus.fn_g36));
    }

    public IEntityLivingData onSpawnWithEgg(IEntityLivingData par1EntityLivingData)
    {
        par1EntityLivingData = super.onSpawnWithEgg(par1EntityLivingData);

        
        
        {
            this.tasks.addTask(4, this.aiArrowAttack);
            this.addRandomArmor();
            this.enchantEquipment();
        }

        this.setCanPickUpLoot(this.rand.nextFloat() < 0.55F * this.worldObj.func_147462_b(this.posX, this.posY, this.posZ));

        if (this.getEquipmentInSlot(4) == null)
        {
            Calendar var2 = this.worldObj.getCurrentDate();

            if (var2.get(2) + 1 == 10 && var2.get(5) == 31 && this.rand.nextFloat() < 0.25F)
            {
                this.setCurrentItemOrArmor(4, new ItemStack(this.rand.nextFloat() < 0.1F ? Blocks.lit_pumpkin : Blocks.pumpkin));
                this.equipmentDropChances[4] = 0.0F;
            }
        }

        return par1EntityLivingData;
    }

    /**
     * sets this entity's combat AI.
     */
    public void setCombatTask()
    {
        
        this.tasks.removeTask(this.aiArrowAttack);
        ItemStack var1 = this.getHeldItem();

        
            this.tasks.addTask(4, this.aiArrowAttack);
        
    }
    
    public void onUpdate()
    {
    	super.onUpdate();
    	
    	/*if(i > 6){
    	 EntityMob entity = null;
         List llist = this.worldObj.getEntitiesWithinAABBExcludingEntity(entity, this.boundingBox.addCoord(this.motionX, this.motionY, this.motionZ).expand(100.0D, 100.0D, 100.0D));
         double d0 = 8.0D;
         //EntityLivingBase entitylivingbase = this;
         if(llist!=null){
             for (int lj = 0; lj < llist.size(); lj++) {
             	
             	Entity entity1 = (Entity)llist.get(lj);
             	if (entity1.canBeCollidedWith())
                 {
             		if (entity1 instanceof EntityMob  || entity1 instanceof EntityFlying  && entity1 != null)
                     {
             		
             			GVCEntitySentryBulletAAG var3 = new GVCEntitySentryBulletAAG(this.worldObj, this);
						double var4 = entity1.posX - this.posX;
             	        double var6 = entity1.posY + (double)entity1.getEyeHeight() - 1.100000023841858D - var3.posY;
             	        double var8 = entity1.posZ - this.posZ;
             	        float var10 = MathHelper.sqrt_double(var4 * var4 + var8 * var8) * 0.2F;
             	        var3.setThrowableHeading(var4, var6 + (double)var10, var8, 2.0F, 12.0F);
             	        this.playSound("gvcguns:gvcguns.fire", 1.0F, 1.0F);
             	        this.worldObj.spawnEntityInWorld(var3);
             	        
             	        
             	       GVCEntitySentryBullet var31 = new GVCEntitySentryBullet(this.worldObj, this);
             	        double var41 = entity1.posX - this.posX;
             	        double var61 = entity1.posY + (double)entity1.getEyeHeight() - 2.100000023841858D - var31.posY;
             	        double var81 = entity1.posZ - this.posZ;
             	        float var101 = MathHelper.sqrt_double(var41 * var41 + var81 * var81) * 0.2F;
             	        var31.setThrowableHeading(var41, var61 + (double)var101, var81, 1.6F, 0.0F);
             	        this.playSound("gvcguns:gvcguns.fire", 1.0F, 1.5F);
             	        this.worldObj.spawnEntityInWorld(var31);
             			
                     }
                 }
             }
         }
         i = 0;
    	}else{
    		++i;
    	}*/
    	
    	//this.getEyeHeight() = 20;
    }
    
    
    
    /**
     * Attack the specified entity using a ranged attack.
     */
    public void attackEntityWithRangedAttack(EntityLivingBase par1EntityLivingBase, float par2)
    {
    	GVCEntitySentryBulletAAG var3 = new GVCEntitySentryBulletAAG(this.worldObj, this);
        double var4 = par1EntityLivingBase.posX - this.posX;
        double var6 = par1EntityLivingBase.posY + (double)par1EntityLivingBase.getEyeHeight() - 1.100000023841858D - var3.posY;
        double var8 = par1EntityLivingBase.posZ - this.posZ;
        float var10 = MathHelper.sqrt_double(var4 * var4 + var8 * var8) * 0.2F;
        var3.setThrowableHeading(var4, var6 + (double)var10, var8, 2.0F, 12.0F);
        this.playSound("gvcguns:gvcguns.fire", 1.0F, 1.0F);
        this.worldObj.spawnEntityInWorld(var3);
        
    }

	public boolean isConverting() {
		return false;
	}
	/**
     * Returns the sound this mob makes when it is hurt.
     */
    protected String getHurtSound()
    {
        return "mob.irongolem.hit";
    }

    /**
     * Returns the sound this mob makes on death.
     */
    protected String getDeathSound()
    {
        return "mob.irongolem.death";
    }

    protected void func_145780_a(int p_145780_1_, int p_145780_2_, int p_145780_3_, Block p_145780_4_)
    {
        this.playSound("mob.irongolem.walk", 1.0F, 1.0F);
    }

    /*public void onUpdate()
    {
    	EntityMob entity = null;
        List llist = this.worldObj.getEntitiesWithinAABBExcludingEntity(entity, this.boundingBox.addCoord(this.motionX, this.motionY, this.motionZ).expand(100.0D, 100.0D, 100.0D));
        double d0 = 8.0D;
        if(llist!=null){
            for (int lj = 0; lj < llist.size(); lj++) {
            	
            	Entity entity1 = (Entity)llist.get(lj);
            	if (entity1.canBeCollidedWith())
                {

                	if (this.targetedEntity != null && this.targetedEntity.isDead)
                    {
                        this.targetedEntity = null;
                    }

                    if (this.targetedEntity == null || this.aggroCooldown-- <= 0)
                    {
                        this.targetedEntity = entity1;

                        if (this.targetedEntity != null)
                        {
                            this.aggroCooldown = 20;
                        }
                    }

                    double d4 = 64.0D;

                    if (this.targetedEntity != null && this.targetedEntity.getDistanceSqToEntity(this) < d4 * d4)
                    {
                        double d5 = this.targetedEntity.posX - this.posX;
                        double d6 = this.targetedEntity.boundingBox.minY + (double)(this.targetedEntity.height / 2.0F) - (this.posY + (double)(this.height / 2.0F));
                        double d7 = this.targetedEntity.posZ - this.posZ;
                        this.renderYawOffset = this.rotationYaw = -((float)Math.atan2(d5, d7)) * 180.0F / (float)Math.PI;

                        if (this.canEntityBeSeen(this.targetedEntity))
                        {
                            if (this.attackCounter == 10)
                            {
                                this.worldObj.playAuxSFXAtEntity((EntityPlayer)null, 1007, (int)this.posX, (int)this.posY, (int)this.posZ, 0);
                            }

                            ++this.attackCounter;

                            if (this.attackCounter == 20)
                            {
                            	GVCEntitySentryBulletAAG var3 = new GVCEntitySentryBulletAAG(this.worldObj, this);
                                double var4 = this.targetedEntity.posX - this.posX;
                                double var6 = this.targetedEntity.posY + (double)this.targetedEntity.getEyeHeight() - 1.100000023841858D - var3.posY;
                                double var8 = this.targetedEntity.posZ - this.posZ;
                                float var10 = MathHelper.sqrt_double(var4 * var4 + var8 * var8) * 0.2F;
                                var3.setThrowableHeading(var4, var6 + (double)var10, var8, 2.0F, 12.0F);
                                this.playSound("gvcguns:gvcguns.fire", 1.0F, 1.0F);
                                this.worldObj.spawnEntityInWorld(var3);
                                this.attackCounter = -40;
                            }
                        }
                        else if (this.attackCounter > 0)
                        {
                            --this.attackCounter;
                        }
                    }
                }
            }
        }
    }
    
    
    /*public EntityMob getClosestVulnerableEntityToEntity(Entity p_72856_1_, double p_72856_2_)
    {
        return this.getClosestVulnerableEntity(p_72856_1_.posX, p_72856_1_.posY, p_72856_1_.posZ, p_72856_2_);
    }

    /**
     * Returns the closest vulnerable player within the given radius, or null if none is found.
     */
    /*public EntityMob getClosestVulnerableEntity(double p_72846_1_, double p_72846_3_, double p_72846_5_, double p_72846_7_)
    {
        double d4 = -1.0D;
        EntityMob entitymob = null;

        for (int i = 0; i < this.playerEntities.size(); ++i)
        {
            EntityMob entitymob1 = (EntityMob)this.playerEntities.get(i);

            if (entitymob1.isEntityAlive())
            {
                double d5 = entitymob1.getDistanceSq(p_72846_1_, p_72846_3_, p_72846_5_);
                double d6 = p_72846_7_;

                if (entitymob1.isSneaking())
                {
                    d6 = p_72846_7_ * 0.800000011920929D;
                }

                if (entitymob1.isInvisible())
                {
                    /*float f = entitymob1.getArmorVisibility();

                    if (f < 0.1F)
                    {
                        f = 0.1F;
                    }//

                    d6 *= (double)(0.7F * 0.1);
                }

                if ((p_72846_7_ < 0.0D || d5 < d6 * d6) && (d4 == -1.0D || d5 < d4))
                {
                    d4 = d5;
                    entitymob = entitymob1;
                }
            }
        }

        return entitymob;
    }*/
    
    
	public static float getMobScale() {
		// TODO 閾ｪ蜍慕函謌舌＆繧後◆繝｡繧ｽ繝�繝峨�ｻ繧ｹ繧ｿ繝�
		return 5;
	}
}
