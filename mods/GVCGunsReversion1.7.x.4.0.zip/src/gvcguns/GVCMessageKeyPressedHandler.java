package gvcguns;
import cpw.mods.fml.common.network.simpleimpl.IMessage;
import cpw.mods.fml.common.network.simpleimpl.IMessageHandler;
import cpw.mods.fml.common.network.simpleimpl.MessageContext;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ChatComponentText;
 
public class GVCMessageKeyPressedHandler implements IMessageHandler<GVCMessageKeyPressed, IMessage> {
 
    @Override
    public IMessage onMessage(GVCMessageKeyPressed message, MessageContext ctx) {
        EntityPlayer entityPlayer = ctx.getServerHandler().playerEntity;
        //受け取ったMessageクラスのkey変数の数字をチャットに出力
        
        if(message.key == 1){
        ItemStack itemstack = ((EntityPlayer)(entityPlayer)).getCurrentEquippedItem();
        int li = itemstack.getMaxDamage() - itemstack.getItemDamage();
	    itemstack.damageItem(li, entityPlayer);
        }
        if(message.key == 2){
        	ItemStack par1ItemStack = ((EntityPlayer)(entityPlayer)).getCurrentEquippedItem();
        	int li = par1ItemStack.getMaxDamage() - par1ItemStack.getItemDamage();
			
	        par1ItemStack.damageItem(-1, entityPlayer);
			//setDamage(par1ItemStack, -1);
			//for(int i = 0; i < this.getMaxDamage() ; ++i)
	        boolean linfinity = EnchantmentHelper.getEnchantmentLevel(Enchantment.infinity.effectId, par1ItemStack) > 0;
			
	        //par1ItemStack.damageItem(li, par3EntityPlayer);
			//setDamage(par1ItemStack, -this.getMaxDamage());
			if (!linfinity) {
				entityPlayer.inventory.consumeInventoryItem(GVCGunsPlus.fn_shell);
			}
			//par2World.playSoundAtEntity(par3EntityPlayer, "random.click", 1.0F, 0.4F / (itemRand.nextFloat() * 0.4F + 0.8F));
			entityPlayer.worldObj.playSoundAtEntity(entityPlayer, "gvcguns:gvcguns.reload", 1.0F, 1.0F);
        }
 
        //entityPlayer.addChatComponentMessage(new ChatComponentText(String.format("Received byte %d", message.key)));
        return null;
    }
}